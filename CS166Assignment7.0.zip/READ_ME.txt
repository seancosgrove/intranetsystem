---------------------------------------------------------------------------------
Welcome to assignment 7 for CS166 Cybersecurity Principles!
---------------------------------------------------------------------------------
This program replicates a login and menu for a company's intranet system.
Users can create an account or login to enter the menu and view the applications.
Every user has different access rights as displayed below.
NOTE: Program will not work if files are still in zipped folder.
Extracting the files and folder onto your desktop or into a new folder will work.
---------------------------------------------------------------------------------
Account information:
---------------------------------------------------------------------------------
User: Admin	Password: administration2	Access: all applications
User: userA	Password: database4		Access: database and schedule applications
User: userB	Password: networking6		Access: network and schedule applications
User: userC	Password: security8		Access: security and schedule applications
User: userD	Password: marketing10		Access: schedule application only (limited priviledged) 
---------------------------------------------------------------------------------
Instructions:
---------------------------------------------------------------------------------
The program starts by prompting the user to login or create a new account.
To test my program, I would start by logging into the different accounts and
testing their accesses into the different applications.

Logging in will fail if you try any random string or you try to use a
different account's password (typing in 'userA' with the password 'administration2').

A successful login will redirect you to the menu, where you can enter '1', '2',
'3', '4', or 'exit' in order to enter the Database Application, Network Application,
Security Application, Schedule Application, or logout, respectively.

If you are granted access, you will be redirected to the application where you
can type 'back' in order to return to the menu.

If you are denied access, you will simply be redirected to the menu.

Because this program utilizes three different .txt files for the usernames,
passwords, and access rights, each account data is encrypted with a salt value at
the end that represents the order of creation in order to link them together.

If you actually open the .txt files themselves, you'll see that the users are
listed as; Admin1, userA2, userB3, userC4, and userD5.

The passwords in the file are all encrypted with the same formula.

The access rights follow the same pattern, using the characters 'd', 'n,', 's',
and 'p' to represent the three different applications in the menu. So in the .txt 
file, the access rights are listed as; pdns1, pd2, pn3, ps4, and p5. 

Whenever you make a new account, you will be given the access right of 'p', which
only gives you access to the Schedule Application.

After creating a new account, logging out, or an error occurs due to typing in
wrong account information, you will be redirected to a prompt that lets you
login or exit the application as a whole.
---------------------------------------------------------------------------------
Encryption Algorithm:
---------------------------------------------------------------------------------
For this assignment, we used a SHA512 hash for the passwords, along with a
psuedo-random salt. I generated a 5 character random salt with capital letters
and numbers using python's string and random functions.

The passwords full encryption with the salt and access value are displayed as:

2903781321d2f934dbbd6c1d54e2e96f40f72828943284ba7812a23c332c9ef84926e38b518f431ab0fbd87b9f887556061d90036c2b6bd2a197b22962b93e4dIPYNO1
af8ff14c178b3828ef75c67cb7cee4c77ef5191bc24b7c332e8304ae64f517b3e2c204cd1df310bfdd20400007435b0091caf908d647ee6b369105ecf428e83eO1UEV2
e446b4e85bd7e3e6261b02ed45b38e7a69aa433b8a2cdbba54e0d299e0830827ee5ddc954888326536daabbaca60998d82d5c0e6d96d07e1344742c4b15898d0JGC993
d78ed5791888536a475fa86b237719a074059138bf3744dc7369dad6ff255754851d32088bf1c2b97c9bbd2c949d81a1e8b61ecb9aee94db423cd40e1b2c5f5b7SYFM4
f5dcda0b2babb48f587608953d8e047e7985b8621b4ef0082d32c63d786ef6b1580f2e0dcc8531eaec82d196eeac5c3660e313aa444ddd9528738388f5ff1b76SH38N5
---------------------------------------------------------------------------------
Created by Sean Cosgrove
6/26/2018