#Sean Cosgrove
#CS 166 Cybersecurity Principles
#Assignment 6
#This program replicates a login and menu to a company's intranet system.
#Users can create an account or log in to enter the menu and goto different applications.

#Define main funtion
def main():

    #Open users file for reading in order to revalidate current salt value (n)
    users_file = open('accounts/users.txt', 'r')
    n = 1
    for line in users_file:
        n += 1
    n = str(n)
    
    #Introduce program and prompt user to make an account or log in
    print ("-----------------------------------------")
    print ("Welcome to our company's intranet system!")
    print ("-----------------------------------------")
    print ("If you need to create an account, type 'new'.")
    print ("To login, type 'login'.")
    setup = str(input(""))

    #Redirect user to make an account or log in
    if setup == 'new':
        create(setup, n)
    elif setup == 'login':
        login(setup)
    else:
        restart()

#Create a new account
def create(setup, n):

    #Import python functions
    import hashlib
    import random
    import string

    try:

        #Open username file
        users_file = open('accounts/users.txt', 'r')

        #Prompt user for account information
        if setup == 'new':
            print ("------------------")
            print ("Password must be 8-25 characters long,")
            print ("have at least one number and one letter.")
            print ("------------------")      
            new_user = str(input('Enter a username: '))
            new_password = str(input('Enter a password: '))
            print ("------------------")

            #Input validation
            new_user_length = len(new_user)
            new_password_length = len(new_password)
            number_string = '0123456789'
            count = 0

            #Count number of numbers in password
            for ch in new_password:
                if ch in number_string:
                    count += 1

            #Check to see if username is already taken
            for line in users_file:
                user = str(line)
                user = line.strip()
                if new_user in user:
                    print("That username is already taken.")
                    create(setup, n)

            #Password must have at least 1 number
            if count == 0:
                print("Your password must have at least 1 number.")
                create(setup, n)

            #Password must have at least 1 letter
            elif count == new_password_length:
                print("Your password must have at least 1 letter.")
                create(setup, n)

            #Password must be at least 8 characters
            elif new_password_length < 8:
                print("Your password must be at least 8 characters long.")
                create(setup, n)

            #Password must be no more than 25 characters
            elif new_password_length > 25:
                print("Your password must be no more than 25 characters long.")
                create(setup, n)

            #Password passes validation
            else:
                print ("Your password checks out!")
                
                #Call write function and restart
                write(new_user, new_password, n)
                print ("Account data accepted.")
                print ("Redirecting...")
                users_file.close()
                restart()

    #Error handling            
    except:
        print('Something went wrong...')
        users_file.close()
        restart()

#Write new account data to files
def write(new_user, new_password, n):

    #Import python functions
    import hashlib
    import random
    import string

    #Open account files for writing
    users_file = open('accounts/users.txt', 'a')
    passwords_file = open('accounts/passwords.txt', 'a')
    access_file = open('accounts/access.txt', 'a')
    salts_file = open('accounts/salts.txt', 'a')

    #Generate random salt
    key = string.ascii_uppercase + string.digits 
    salt = ''.join(random.choice(key) for _ in range(5))

    #Hash plaintext password
    hash = hashlib.sha512(new_password.encode()).hexdigest()
    
    #Combine encrypted password and salt
    encryption = hash + salt

    #Write data to files
    users_file.write(new_user)
    users_file.write(n)
    users_file.write('\n')
    passwords_file.write(encryption)
    passwords_file.write(n)
    passwords_file.write('\n')
    access_file.write('p')
    access_file.write(n)
    access_file.write('\n')
    salts_file.write(salt)
    salts_file.write('\n')

    #Close files
    users_file.close()
    passwords_file.close()
    access_file.close()
        
#Login to an existing account
def login(setup):

    #Import python functions
    import hashlib
    import random
    import string

    try:
        
        #Open users and passwords files for reading
        users_file = open('accounts/users.txt', 'r')
        passwords_file = open('accounts/passwords.txt', 'r')
        access_file = open('accounts/access.txt', 'r')

        #Prompt user for login information
        if setup == 'login':
            print('---------')
            user_attempt = str(input('Username: '))
            password_attempt = str(input('Password: '))
            print('---------')

            #Hash plaintext password
            hash = hashlib.sha512(password_attempt.encode()).hexdigest()
            encryption = hash
    
            #Input validation
            user_length = len(user_attempt)
            password_length = len(password_attempt)
            number_string = '0123456789'
            count = 0

            #Count number of numbers in password
            for ch in password_attempt:
                if ch in number_string:
                    count += 1

            #Password must have at least 1 number
            if count == 0:
                print ('Username or password was incorrect.')
                print ('Redirecting...')
                users_file.close()
                passwords_file.close()
                access_file.close()
                restart()

            #Password must have at least 1 letter
            if count == password_length:
                print ('Username or password was incorrect.')
                print ('Redirecting...')
                users_file.close()
                passwords_file.close()
                access_file.close()
                restart()

            #Password minimum 8 characters
            elif password_length < 8:
                print ('Username or password was incorrect.')
                print ('Redirecting...')
                users_file.close()
                passwords_file.close()
                access_file.close()
                restart()

            #Password maximum 25 characters    
            elif password_length > 25:
                print ('Username or password was incorrect.')
                print ('Redirecting...')
                users_file.close()
                passwords_file.close()
                access_file.close()
                restart()

            #Prevent empty username field
            elif user_length < 1:
                print ('Username or password was incorrect.')
                print ('Redirecting...')
                users_file.close()
                passwords_file.close()
                access_file.close()
                restart()                

            #Check username in file and strip salt value from end of string
            for line in users_file:
                user = str(line)
                user = line.strip()
                if user_attempt in user:
                    user = str(user)
                    user = line.strip()
                    ch = user[-1:]
                
            #Create encrypted password with attempted password and salt value, then check in file
            for line in passwords_file:
                password = str(line)
                password = line.strip()
                salt = password[128:133:1]
                encrypt = encryption + salt + ch
                if encrypt in password:
                    print ('Login success!')
                    print ('Redirecting...')
                    login_status = 'T'
                    
            #If login was successful, look in access file for specific user's access rights
            if login_status == 'T':
                for line in access_file:
                    access = str(line)
                    access = line.strip()
                    if ch in access:
                        access = access[:-1]
                        menu(access)
                        
            #If login was unsuccesful, close files and restart
            if login_status != 'T':
                print ('Username or password was incorrect.')
                print ('Redirecting...')
                users_file.close()
                passwords_file.close()
                access_file.close()
                restart()
                    
        #Close files and restart           
        else:
            users_file.close()
            passwords_file.close()
            access_file.close()
            restart()

    #Error Handling
    except:
        print('Username or password was incorrect.')
        print('Redirecting...')
        users_file.close()
        passwords_file.close()
        access_file.close()
        restart()

#Menu options after succesfully logging in
def menu(access):

    #Prompt user to enter an application or logout
    print('-----------------------------------------------')
    print('Menu: Databases | Network | Security | Schedule')
    print('-----------------------------------------------')
    print('Type 1 for Databases, 2 for Network, 3 for Security, and 4 for Schedule.')
    print("Type 'exit' to logout.") 
    path = str(input(''))

    #If user selects an application, check to see if they have access and then redirect
    if path == '1' and 'd' in access:
        print ('Access granted!')
        print ('Redirecting...')
        database(access)
    elif path == '2' and 'n' in access:
        print ('Access granted!')
        print ('Redirecting...')
        network(access)
    elif path == '3' and 's' in access:
        print ('Access granted!')
        print ('Redirecting...')
        security(access)
    elif path == '4' and 'p' in access:
        print ('Access granted!')
        print ('Redirecting...')
        schedule(access)
    elif path == 'exit':
        print ('Logging out...')
        print ('Redirecting...')
        restart()
    else:
        print ('Access has been denied.')
        print ('Redirecting...')
        menu(access)

#Database path
def database(access):

    #Prompt user to enter a command or go back to the menu
    print ('--------------------')
    print ('Database Application')
    print ('--------------------')
    print ('No actions are availible right now.')
    print ("Type 'back' to return to the menu.")
    command = str(input(''))
    if command == 'back':
        menu(access)
    else:
        print('Command does not exist.')
        print('Redirecting...')
        database(access)

#Network path
def network(access):

    #Prompt user to enter a command or go back to the menu
    print ('-------------------')
    print ('Network Application')
    print ('-------------------')
    print ('No actions are availible right now.')
    print ("Type 'back' to return to the menu.")
    command = str(input(''))
    if command == 'back':
        menu(access)
    else:
        print('Command does not exist.')
        print('Redirecting...')
        network(access)

#Security path
def security(access):

    #Prompt user to enter a command or go back to the menu
    print ('--------------------')
    print ('Security Application')
    print ('--------------------')
    print ('No actions are availible right now.')
    print ("Type 'back' to return to the menu.")
    command = str(input(''))
    if command == 'back':
        menu(access)
    else:
        print('Command does not exist.')
        print('Redirecting...')
        security(access)

#Schedule path
def schedule(access):

    #Display work schedule
    print ('--------------------')
    print ('Schedule Application')
    print ('--------------------')
    print ('The schedule is not availible right now.')
    print ("Type 'back' to return to the menu.")
    command = str(input(''))
    if command == 'back':
        menu(access)
    else:
        print('Command does not exist.')
        print('Redirecting...')
        schedule(access)

#Define function used to restart or logout
def restart():

    #Prompt user to login or quit program entirely
    print('---------------------------------------------')
    print("To login, type 'login'.")
    print("To quit, type 'exit'.")
    setup = str(input(''))
    if setup == 'login':
        login(setup)
    elif setup == 'exit':
        print('Exiting application...')
        print('Goodbye.')
    else:
        print('Exiting application...')
        print('Goodbye.')

#Close main function
main()
